package com.mvpt.service;

import com.mvpt.model.Customer;

public interface ICustomerService extends IGeneralService<Customer> {
}
