package com.mvpt.repository;

import com.mvpt.model.Customer;

public interface ICustomerRepository extends IGeneralRepository<Customer>{
}
